/*-------------------------------------------------------------------------
*
* Copyright (c) 2004-2011, PostgreSQL Global Development Group
*
*
*-------------------------------------------------------------------------
*/
package org.postgresql.jdbc3;

import org.postgresql.ds.PGConnectionPoolDataSource;

public class Jdbc3ConnectionPool extends PGConnectionPoolDataSource
{
}
